<?php __halt_compiler();
/**
 * This file was created by All In One Security (AIOS) plugin.
 * The file is required for storing and retrieving your firewall's settings.
 */
{"aios_brute_force_secret_cookie_name":"aios_brute_force_secret_7b243ffe7b1ad5a3631f1d0318eee631","aios_cookie_based_brute_force_redirect_url":"http:\/\/127.0.0.1","aios_brute_force_cookie_salt":"qe04wffn6qg8hrll06lte2xy6vjedcbi7yujkwkrljbhszyhrdnmjsnvdgoaegi6i6hqinglbs66vtapz9nccznrwkvvyhdkop8fhnhlsohktyrnysiqdq0clg8txw37","aios_brute_force_attack_prevention_pw_protected_exception":"","aiowps_blacklist_user_agents":[],"aios_brute_force_attack_prevention_ajax_exception":"","aiowps_6g_block_request_methods":{"0":"DEBUG","1":"MOVE","3":"TRACK"},"aiowps_6g_block_query":true,"aiowps_6g_block_request":true,"aiowps_6g_block_referrers":true,"aiowps_6g_block_agents":true,"aios_enable_brute_force_attack_prevention":"0"}